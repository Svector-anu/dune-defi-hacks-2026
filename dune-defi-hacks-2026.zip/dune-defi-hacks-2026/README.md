# 2026 DeFi Hacks & Exploits — Dune Analytics

On-chain security analysis of all major DeFi exploits in 2026 (Jan–Apr 19).

## Live Dashboard
👉 [dune.com/anu67/2026-defi-hacks-exploits-full-security-analysis](https://dune.com/anu67/2026-defi-hacks-exploits-full-security-analysis)

## Summary
- **20 tracked incidents** · **$722M+ in total losses** · Jan 1 – Apr 19, 2026
- April 2026 alone: ~83% of all losses (Kelp DAO $293M + Drift Protocol $285M)
- North Korea (Lazarus Group) attributed to ~39% of losses by value

## Queries

| File | Dune ID | Description |
|------|---------|-------------|
| `queries/7346396_monthly_loss_trend.sql` | [7346396](https://dune.com/queries/7346396) | Monthly loss aggregation |
| `queries/7346397_loss_by_sector.sql` | [7346397](https://dune.com/queries/7346397) | Breakdown by protocol sector |
| `queries/7346399_attack_vectors.sql` | [7346399](https://dune.com/queries/7346399) | Breakdown by attack vector |
| `queries/7346402_full_incident_table.sql` | [7346402](https://dune.com/queries/7346402) | Full 20-incident table |
| `queries/7346406_attacker_attribution.sql` | [7346406](https://dune.com/queries/7346406) | Attacker origin breakdown |

## Key Findings
- **Bridge verification flaws** + **social engineering** = 80%+ of losses by value
- **Smart contract bugs** lead by incident count but cause far less dollar damage
- **Liquid Restaking** and **DEX/Perps** are the highest-loss sectors in 2026
- Hyperbridge exploit (Apr 13): MMR proof verification flaw, $2.5M revised loss

## Data Sources
Halborn · DefiLlama · Chainsec · TheStreet Crypto · BeInCrypto · PeckShield · CoinGenius

## GitHub Sync (Dune Plus)
`queries.yml` is pre-configured for Dune's GitHub Sync feature.
